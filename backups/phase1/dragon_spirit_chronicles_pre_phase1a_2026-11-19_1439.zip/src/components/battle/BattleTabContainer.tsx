import React, { useMemo, useState } from 'react';
import { useGame } from '../../context/GameContext';
import { getNextStageId, getStageById } from '../../data/stagesData';
import { BattleSimulationResult } from '../../types/game';
import { BattleResultModal } from './BattleResultModal';
import { CombatArenaScreen } from './CombatArenaScreen';
import { FormationScreen } from './FormationScreen';
import { StageMapScreen } from './StageMapScreen';

type BattleViewMode = 'map' | 'formation' | 'combat';

export const BattleTabContainer: React.FC = () => {
  const { state, completeBattleVictory, setActiveTab } = useGame();
  const [viewMode, setViewMode] = useState<BattleViewMode>('map');
  const [battleResult, setBattleResult] = useState<BattleSimulationResult | null>(null);
  const [combatKey, setCombatKey] = useState(0);
  const [challengedStageId, setChallengedStageId] = useState<string>(
    state.stageProgress.currentStage
  );

  const stage = useMemo(
    () => getStageById(challengedStageId),
    [challengedStageId]
  );

  const handleOpenFormation = () => {
    setChallengedStageId(state.stageProgress.currentStage);
    setBattleResult(null);
    setViewMode('formation');
  };

  const handleStartCombat = () => {
    setBattleResult(null);
    setCombatKey((k) => k + 1);
    setViewMode('combat');
  };

  const handleCombatComplete = (result: BattleSimulationResult) => {
    if (result.victory && result.loot) {
      completeBattleVictory(stage.id, result.loot);
    }
    setBattleResult(result);
  };

  const handleContinueFromResult = () => {
    const wasVictory = Boolean(battleResult?.victory);
    const nextId = getNextStageId(stage.id);
    setBattleResult(null);

    if (wasVictory && state.autoBattle && nextId) {
      setChallengedStageId(nextId);
      setCombatKey((k) => k + 1);
      setViewMode('combat');
    } else {
      setViewMode('map');
    }
  };

  return (
    <div className="relative flex-1 min-h-0 flex flex-col overflow-hidden">
      {viewMode === 'map' && (
        <StageMapScreen onOpenFormation={handleOpenFormation} />
      )}
      {viewMode === 'formation' && (
        <FormationScreen
          onBack={() => setViewMode('map')}
          onStartCombat={handleStartCombat}
        />
      )}
      {viewMode === 'combat' && (
        <CombatArenaScreen
          key={`${stage.id}-${combatKey}`}
          stage={stage}
          onExit={() => {
            setBattleResult(null);
            setViewMode('map');
          }}
          onComplete={handleCombatComplete}
        />
      )}

      {battleResult && (
        <BattleResultModal
          stage={stage}
          result={battleResult}
          onContinue={handleContinueFromResult}
          onGoToTab={(tab) => {
            setBattleResult(null);
            setViewMode('map');
            setActiveTab(tab);
          }}
        />
      )}
    </div>
  );
};
